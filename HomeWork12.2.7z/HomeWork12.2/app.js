document.querySelector('.Buttons').addEventListener('click', function (event) {
    alert('Ви натиснули на кпоку:' + event.target.innerText)
})